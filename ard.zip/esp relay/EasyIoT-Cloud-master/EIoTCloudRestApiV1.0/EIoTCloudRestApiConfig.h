#ifndef EIoTCloudRestApiConfig_h
#define EIoTCloudRestApiConfigi_h


// uncomentwhen debugging
//#define DEBUG

#endif

