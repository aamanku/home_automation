#ifndef EIoTCloudRestApiConfig_h
#define EIoTCloudRestApiConfigi_h

// define your access point username and password
#define AP_SSID     "xxx"
#define AP_PASSWORD "xxx"


// uncomentwhen debugging
#define DEBUG

#endif

